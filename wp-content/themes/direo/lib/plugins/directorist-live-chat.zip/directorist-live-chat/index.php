<?php
// silence is golder