<?php
 if(!empty($args['listing_ino']['DGR'])) extract($args['listing_ino']['DGR']); // multiple image data
 if(!empty($args['listing_ino']['DGR_settings'])) extract($args['listing_ino']['DGR_settings']); // extract the settings of multiple image
/**/
//

