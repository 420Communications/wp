<?php
//silent is golder