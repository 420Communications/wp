<?php
/**
 * @package Directoirst
 * @since 2.0.3
 */

?>

<div>
    <p><?php _e( 'There is no plan assigned to your listing. To continue editing, please purchase a plan first or assign a plan from the ', 'directorst-woocommerce-pricing-plans' );?><a href="<?php echo esc_url( ATBDP_Permalink::get_dashboard_page_link() ); ?>"><?php _e( 'dashboard', 'directorst-woocommerce-pricing-plans' )?></a></p>
</div>