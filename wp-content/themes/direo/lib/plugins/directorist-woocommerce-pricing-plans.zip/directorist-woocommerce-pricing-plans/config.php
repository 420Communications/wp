<?php
// Plugin version.
if ( ! defined( 'DWPP_VERSION' ) ) {define( 'DWPP_VERSION',  dwpp_get_version_from_file_content( DWPP_FILE ) );}
// Plugin Folder Path.
if ( ! defined( 'DWPP_DIR' ) ) { define( 'DWPP_DIR', plugin_dir_path( DWPP_FILE ) ); }
// Plugin Folder URL.
if ( ! defined( 'DWPP_URL' ) ) { define( 'DWPP_URL', plugin_dir_url( DWPP_FILE ) ); }
// Plugin Root File.
if ( ! defined( 'DWPP_BASE' ) ) { define( 'DWPP_BASE', plugin_basename( DWPP_FILE ) ); }
// Plugin Includes Path
if ( !defined('DWPP_INC_DIR') ) { define('DWPP_INC_DIR', DWPP_DIR.'inc/'); }
// Plugin classes Path
if ( !defined('DWPP_CLASSES_DIR') ) { define('DWPP_CLASSES_DIR', DWPP_DIR.'inc/classes/'); }
// Plugin views Path
if ( !defined('DWPP_VIEWS_DIR') ) { define('DWPP_VIEWS_DIR', DWPP_DIR.'inc/views/'); }
// Plugin Assets Path
if ( !defined('DWPP_ASSETS') ) { define('DWPP_ASSETS', DWPP_URL.'assets/'); }
// Plugin Template Path
if ( !defined('DWPP_TEMPLATES_DIR') ) { define('DWPP_TEMPLATES_DIR', DWPP_DIR.'templates/'); }
// Plugin Language File Path
if ( !defined('DWPP_LANG_DIR') ) { define('DWPP_LANG_DIR', dirname(plugin_basename( DWPP_FILE ) ) . '/languages'); }
// Plugin Post Type
if ( !defined('ATBDP_POST_TYPE') ) { define('ATBDP_POST_TYPE', 'at_biz_dir'); }
if ( !defined('ATBDP_ORDER_POST_TYPE') ) { define('ATBDP_ORDER_POST_TYPE', 'atbdp_orders'); }
if ( !defined('DWPP_Pricing_Plans_POST_TYPE') ) { define('DWPP_Pricing_Plans_POST_TYPE', 'DWPP_Pricing_Plans'); }
// plugin author url
if (!defined('ATBDP_AUTHOR_URL')) {
    define('ATBDP_AUTHOR_URL', 'https://directorist.com');
}
// post id from download post type (edd)
if (!defined('ATBDP_WOO_PRICING_PLAN_POST_ID')) {
    define('ATBDP_WOO_PRICING_PLAN_POST_ID', 13784 );
}
