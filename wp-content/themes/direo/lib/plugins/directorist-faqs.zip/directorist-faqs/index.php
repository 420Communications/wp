<?php
//protects direct folder access